import {initializeHooks} from "./hooks.js";

initializeHooks();
